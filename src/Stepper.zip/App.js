import React from 'react';
import Header from './Components/Header'; 
import Home from './Pages/Home';
import Company from './Pages/Company';

import Footer from './Components/Footer'; 
const App = () => {
  return (
   <>
     {/* <Header />
      <Home/>
      <Footer/> */}
      <Company/> 
      </>
       );
      }  
      
export default App;
